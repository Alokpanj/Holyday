import java.util.List;

public class Main {

	public static void main(String[] args) {

		TravelAgency ta= new TravelAgency();
		List<Package> l=ta.generatePackageCost("src/VarshTourPackageDetails.txt");
		 for(Package ar:l)
		   {
			   System.out.println(ar.toString());
		   }
		 l=ta.findPackagesWithMinimumNumberOfDays();
		 for(Package ar:l)
		   {
			   System.out.println(ar.toString());
		   }
	}

}
