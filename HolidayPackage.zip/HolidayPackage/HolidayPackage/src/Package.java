
public class Package {
	private String packageId;
	private String sourcePlace;
	private String destinationPlace;
	private double basicFare;
	private int noOfDays;
	private double packageCost;
	
	public String getPackageId() {
		return packageId;
	}
	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}
	public String getSourcePlace() {
		return sourcePlace;
	}
	public void setSourcePlace(String sourcePlace) {
		this.sourcePlace = sourcePlace;
	}
	public String getDestinationPlace() {
		return destinationPlace;
	}
	public void setDestinationPlace(String destinationPlace) {
		this.destinationPlace = destinationPlace;
	}
	public double getBasicFare() {
		return basicFare;
	}
	public void setBasicFare(double basicFare) {
		this.basicFare = basicFare;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public double getPackageCost() {
		return packageCost;
	}
	public void setPackageCost(double packageCost) {
		this.packageCost = packageCost;
	}

    //write the required business logic methods as expected in the question description
	public void calculatePackageCost() {
		//fill your code here
		double packageCost=0.0;
		double basicFare=getBasicFare();
		int noOfDays=getNoOfDays();
		int discount=0;
		if(noOfDays<=5){
			discount=0;
			
		}
		else if(noOfDays>5 && noOfDays<=8){
			discount=3;
		}
		else if(noOfDays>8  && noOfDays<=10){
			discount=5;
			
		}
		else{
			discount=7;
		}
		double temp=(double)(100-discount)/100.00;
		double discountedAmount=temp*(basicFare*noOfDays);
		packageCost=1.12*discountedAmount;
		
		setPackageCost((int)(packageCost*100)/100.00);
	}
	@Override
	public String toString() {
		return "Package [packageId=" + packageId + ", sourcePlace=" + sourcePlace + ", destinationPlace="
				+ destinationPlace + ", basicFare=" + basicFare + ", noOfDays=" + noOfDays + ", packageCost="
				+ packageCost + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(basicFare);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((destinationPlace == null) ? 0 : destinationPlace.hashCode());
		result = prime * result + noOfDays;
		temp = Double.doubleToLongBits(packageCost);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((packageId == null) ? 0 : packageId.hashCode());
		result = prime * result + ((sourcePlace == null) ? 0 : sourcePlace.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Package other = (Package) obj;
		if (Double.doubleToLongBits(basicFare) != Double.doubleToLongBits(other.basicFare))
			return false;
		if (destinationPlace == null) {
			if (other.destinationPlace != null)
				return false;
		} else if (!destinationPlace.equals(other.destinationPlace))
			return false;
		if (noOfDays != other.noOfDays)
			return false;
		if (Double.doubleToLongBits(packageCost) != Double.doubleToLongBits(other.packageCost))
			return false;
		if (packageId == null) {
			if (other.packageId != null)
				return false;
		} else if (!packageId.equals(other.packageId))
			return false;
		if (sourcePlace == null) {
			if (other.sourcePlace != null)
				return false;
		} else if (!sourcePlace.equals(other.sourcePlace))
			return false;
		return true;
	}
	
	
}