
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TravelAgency {
    
    //write the required business logic methods as expected in the question description
	
	public List<Package> generatePackageCost(String filePath) {
		
		List<Package> packageList = new ArrayList<Package>();
		File file = null;
		Scanner scanner = null;
		try {
			file = new File(filePath);
			scanner=new Scanner(file);
			String s = null;
			String sp[];
			while (scanner.hasNext()) {
				s=scanner.next();
				sp = s.split(",");
				Package packageObj = new Package();
				
				try {
					if (validate(sp[0])) {
						packageObj.setPackageId(sp[0]);
					}
					packageObj.setPackageId(sp[0]);
					packageObj.setSourcePlace(sp[1]);
					packageObj.setDestinationPlace(sp[2]);
					packageObj.setBasicFare(Double.parseDouble(sp[3]));
					packageObj.setNoOfDays(Integer.parseInt(sp[4]));
					packageObj.calculatePackageCost();
					packageList.add(packageObj);
					
				} catch (InvalidPackageIdException e) {
					e.getMessage();
				}
			}
			scanner.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return packageList;

		
		
	}
	
	public boolean validate(String packageId) throws InvalidPackageIdException {
		
    	if(packageId.matches("^[0-9]{3}[/][A-Z]{3}$")){
    		return true;
    	}
    	else{
    		throw new InvalidPackageIdException();
    	}
    	
    	
	}
	
	
	public List<Package> findPackagesWithMinimumNumberOfDays() {
		
		List<Package> list=new ArrayList<Package>();
		try(Connection connection=new DBHandler().establishConnection()){
			
			PreparedStatement pst=connection.prepareStatement("select * from package_details where no_of_days = (select min(no_of_days) from package_details)");
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				Package packageObj;
				packageObj = new Package();
				packageObj.setPackageId(rs.getString(1));
				packageObj.setSourcePlace(rs.getString(2));
				packageObj.setDestinationPlace(rs.getString(3));
				packageObj.setNoOfDays(rs.getInt(4));
				packageObj.setPackageCost(rs.getDouble(5));
         
                list.add(packageObj);
          }

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
		
	}
}

